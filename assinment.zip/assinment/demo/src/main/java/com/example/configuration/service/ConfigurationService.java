package com.example.configuration.service;

import com.example.configuration.dto.ConfigurationCreateDto;
import com.example.configuration.dto.ConfigurationDto;
import com.example.configuration.dto.ConfigurationUpdateDto;
import com.example.configuration.model.Configuration;
import com.example.configuration.repository.ConfigurationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ConfigurationService {

    @Autowired
    private ConfigurationRepository repository;

    public ConfigurationDto createConfiguration(ConfigurationCreateDto createDto) {
        Configuration configuration = new Configuration();
        configuration.setCountryCode(createDto.getCountryCode());
        configuration.setRequirements(createDto.getRequirements());
        Configuration savedConfig = repository.save(configuration);
        return toDto(savedConfig);
    }

    public ConfigurationDto getConfiguration(String countryCode) {
        Optional<Configuration> config = repository.findByCountryCode(countryCode);
        return config.map(this::toDto).orElse(null);
    }

    public ConfigurationDto updateConfiguration(ConfigurationUpdateDto updateDto) {
        Optional<Configuration> existingConfig = repository.findByCountryCode(updateDto.getCountryCode());
        if (existingConfig.isPresent()) {
            Configuration configuration = existingConfig.get();
            configuration.setRequirements(updateDto.getRequirements());
            Configuration updatedConfig = repository.save(configuration);
            return toDto(updatedConfig);
        }
        return null;
    }

    public void deleteConfiguration(String countryCode) {
        Optional<Configuration> config = repository.findByCountryCode(countryCode);
        config.ifPresent(repository::delete);
    }

    private ConfigurationDto toDto(Configuration configuration) {
        ConfigurationDto dto = new ConfigurationDto();
        dto.setId(configuration.getId());
        dto.setCountryCode(configuration.getCountryCode());
        dto.setRequirements(configuration.getRequirements());
        return dto;
    }
}
