package com.example.configuration.dto;

import com.example.configuration.model.Configuration;

import java.util.Map;

public class ConfigurationUpdateDto {
    private String countryCode;
    private Map<String, String> requirements;

    public String getCountryCode() {
        return null;
    }

    public Configuration getRequirements() {
        return null;
    }

    // Getters and Setters
}

