package com.example.configuration.dto;

import java.util.Map;

public class ConfigurationDto {
    private Long id;
    private String countryCode;
    private Map<String, String> requirements;

    // Getters and Setters
}


