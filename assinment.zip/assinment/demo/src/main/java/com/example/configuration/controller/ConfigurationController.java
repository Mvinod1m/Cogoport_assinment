package com.example.configuration.controller;

import com.example.configuration.dto.ConfigurationCreateDto;
import com.example.configuration.dto.ConfigurationDto;
import com.example.configuration.dto.ConfigurationUpdateDto;
import com.example.configuration.service.ConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/configurations")
public class ConfigurationController {

    @Autowired
    private ConfigurationService service;

    @PostMapping("/create")
    public ConfigurationDto createConfiguration(@RequestBody ConfigurationCreateDto createDto) {
        return service.createConfiguration(createDto);
    }

    @GetMapping("/{countryCode}")
    public ConfigurationDto getConfiguration(@PathVariable String countryCode) {
        return service.getConfiguration(countryCode);
    }

    @PostMapping("/update")
    public ConfigurationDto updateConfiguration(@RequestBody ConfigurationUpdateDto updateDto) {
        return service.updateConfiguration(updateDto);
    }

    @DeleteMapping("/delete/{countryCode}")
    public void deleteConfiguration(@PathVariable String countryCode) {
        service.deleteConfiguration(countryCode);
    }
}

